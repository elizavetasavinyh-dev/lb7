unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    ListBox1: TListBox;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.Button1Click(Sender: TObject);
var
  f: File of Integer;
  i: Integer;
begin
  AssignFile(f, 'mytypefile.dat');
  Rewrite(f);
  Randomize;          // инициализация генератора случайных чисел
  for i := 1 to 10 do
    Write(f, Random(1000));
  CloseFile(f);
  ShowMessage('Файл сформирован (10 случайных чисел)');
end;

procedure TForm1.Button2Click(Sender: TObject);
var
  f: File of Integer;
  k: Integer;
begin
  if not FileExists('mytypefile.dat') then
  begin
    ShowMessage('Файл не найден. Сначала сформируйте его.');
    Exit;
  end;
  ListBox1.Clear;
  AssignFile(f, 'mytypefile.dat');
  Reset(f);
  while not Eof(f) do
  begin
    Read(f, k);
    ListBox1.Items.Add(IntToStr(k));
  end;
  CloseFile(f);
end;

end.
